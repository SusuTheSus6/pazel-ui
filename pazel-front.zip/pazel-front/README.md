Open terminal in the Pazel-Backend folder.<br/>

---
open a new venv in this folder<br/>
-- create a new venv if not exists<br/>
-- install flask and flask-cors in this venv
-- Run the file index.py with this venv

---

run the following commands:<br/>
-- cd pazel-front<br/>
-- npm install (may take a minute)<br/>
-- npm run dev

    